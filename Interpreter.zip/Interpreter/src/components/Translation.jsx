import React from "react";

export default function Translation() {
  return <div></div>;
}
