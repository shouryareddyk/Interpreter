import React from "react";

export default function Transcription() {
  return <div></div>;
}
